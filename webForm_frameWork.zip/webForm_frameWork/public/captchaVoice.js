
//initialize speech recognition API
window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

const recognition = new SpeechRecognition(); //initialize my instance of speech recognition
recognition.interimResults = true; //return results while still working on current recognition

//this is where your speech-to-text results will appear
let p = document.createElement("p")
const words = document.querySelector(".words-container")
words.appendChild(p)

       const sound  = new Audio()
       const button = document.getElementById("sound")
       button.addEventListener("click", playSound)


//I want to select and change the color of the body, but this could be any HTML element on your page
let body = document.querySelector("body")

let fruits = ["lemon","banana","orange","Apple","mango"]  // [make s as an array or link to dictionry + chose one randomly]
var audio_name = fruits [Math.floor(Math.random() * fruits.length)];
document.getElementById("demo22").innerHTML = audio_name;


const WS = fruits.map(fruits => {
  //I need to change all color names to lower case, because comparison between words will be case sensitive
  return fruits.toLowerCase()
})

//once speech recognition determines it has a "result", grab the texts of that result, join all of them, and add to paragraph
recognition.addEventListener("result", e => {
  const transcript = Array.from(e.results)
  .map(result => result[0])
  .map(result => result.transcript)
  .join("")
  p.innerText = transcript

  //once speech recognition determines it has a final result, create a new paragraph and append it to the words-container
  //this way every time you add a new p to hold your speech-to-text every time you're finished with the previous results
  if (e.results[0].isFinal) {
    p = document.createElement("p")
    words.appendChild(p)
  }


  //for each result, map through all color names and check if current result (transcript) contains that color
  //i.e. see if a person said any color name you know
  WS.forEach(fruits => {
    //if find a match, change your background color to that color
    if (audio_name == transcript)//== filename ??
    document.getElementById("demo").innerHTML = " Yes, You are human!";
    else
    document.getElementById("demo").innerHTML = " Sorry try again!";
    //  body.style.backgroundColor = color; //pass

  })
})

//add your functionality to the start and stop buttons
function startRecording() {
  recognition.start();
  recognition.addEventListener("end", recognition.start)
  document.getElementById("stop").addEventListener("click", stopRecording)
}

function stopRecording() {
  console.log("okay I'll stop")
  recognition.removeEventListener("end", recognition.start)
  recognition.stop();
}
function playSound() {
sound.src ="http://localhost:5000/audio/"+audio_name+".mp3"
  sound.play()
}
