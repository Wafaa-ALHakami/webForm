var changeFontStyle = function (font) {
  document.getElementById(
    "output-text").style.fontFamily
        = font.value;
}
