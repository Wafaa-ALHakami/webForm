$(function () {
    $(".font-button").bind("click", function () {
        var size = parseInt($('#content').css("font-size"));
        if ($(this).hasClass("plus")) {
            size = size + 2;
            if (size >= 32)
            {
                size = 32;
            }
        }
        else {
            size = size - 2;
            if (size <= 10)
            {
                size = 10;
            }

        }
        $('#content').css("font-size", size);
    });
});
