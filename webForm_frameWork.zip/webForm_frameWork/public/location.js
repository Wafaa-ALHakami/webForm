


        // fetch('http://ip-api.com/json').then(response=>{
        //   console.log("location : ",response.json());
        // }).catch(err=>{
        //   console.log(err);
        // })


        const countryInfo = [
          {
            country:"India",
            state:["Delhi","Maharashtra","West Bengal","Tamilnadu"]
          },
          {
            country:"Saudi Arabia",
            state:["Riyad","Makkah","Medina"],

          }
        ]

        const stateInfo = [
          {
            state:"Delhi",
            cities:["New Delhi"]
          },
          {
            state:"Maharashtra",
            cities:["Pune","Mumbai","Nagpur","Nashik"],
          },
          {
            state:"West Bengal",
            cities:["Kolkata","Durgapur","Asansol"],
          },
          {
            state:"Tamilnadu",
            cities:["Chennai","Madurai","Salem"],
          },
          {
            state:"Riyad",
            cities:["Al-Kharj","Ad-Dir'iyah","Ad-Dawādmī"],
          },
          {
            state:"Makkah",
            cities:["Jeddah","Taif","Mecca"],
          },
          {
            state:"Medina",
            cities:["Al-Madīnah","Al-Ḥinākīyah","Al-Miḥfa"],
          },


        ]



        const url = "http://localhost:5000/upload"
        const inpFile = document.querySelector("form #file");
        const DETAIL = {
          Name: document.querySelector("#fName"),
          Email: document.querySelector("#email"),
          Phone: document.querySelector("#phone"),
          Country: document.querySelector("#country"),
          City: document.querySelector("#city"),
          State: document.querySelector("#state"),
          Zip: document.querySelector("#zip"),
          Age: document.querySelector("#age"),
          Pass: document.querySelector("#pass"),
        }

        //this is the function which is fetching geolocation of the user's public ip from an api
        async function getGeoLocation(){
          let apiKey = "1be9a6884abd4c3ea143b59ca317c6b2"
        try{
          const response = await fetch(`https://ipgeolocation.abstractapi.com/v1/?api_key=${apiKey}`);
          response.json().then(async (data)=>{
            // console.log("location : ",data);




            //converting data into arabic

            translate.engine = "google"; // Or "yandex", "libre", "deepl"
            let englishCountry = await translate(data.country, "en");
            let englishCity = await translate(data.city, "en");
            let englishRegion = await translate(data.region, "en");
            // console.log(arabicCountry);

            //below is the code which is filling the address fields automatically
            DETAIL.Country.value = englishCountry;
            DETAIL.City.value = englishCity;
            DETAIL.State.value = englishRegion;
            DETAIL.Zip.value = data.postal_code;

          })


        }catch(err){
          console.log(err);
        }
       }

       //this function is to set the fields to default value of manual form

       function setAllValueDefault(){
        let country = document.querySelector('#manual_country_value');
       let city = document.querySelector('#manual_city_value');
       let state = document.querySelector('#manual_region_value');
       let zip = document.querySelector('#manual_zip_value');
       country.value = "Select Country"
       city.value = "Select City"
       state.value = "Select Region/State";
       zip.value = "Select Zip/Pin"
       }


       //here i calling above functions

       getGeoLocation();
       setAllValueDefault();



      //this function for showing the manual form table when we click on the add manual address button

       function addManualAddress(){
          const autoMaticShipping = document.querySelector('.shipping__address__auto');
          const manualShipping = document.querySelector('.shipping__address__manual');

          autoMaticShipping.setAttribute('style','display:none');
          manualShipping.setAttribute('style','display:block')
       }

       //this function is checking whether country selected and then showing city

       function checkCountry(){
         let country = document.querySelector('#manual_country_value');
         let state = document.querySelector('.manual_region');
         let stateSelect = document.querySelector('#manual_region_value');

         stateSelect.textContent = "";


         let foundCountry = countryInfo.filter((item)=>{
           return item.country.toLowerCase()===country.value.toLowerCase();
         });
        //  console.log("found country : ",foundCountry);

         if(foundCountry.length > 0){
          foundCountry = foundCountry[0];
          let selectOption = document.createElement('option');
          selectOption.textContent = "Select Region/State";
            stateSelect.appendChild(selectOption);
          foundCountry.state.forEach((item)=>{
            let option = document.createElement('option');
            option.value = item;
            option.textContent = item;
            stateSelect.appendChild(option);
          })
         }

         if(country.value && country.value.toLowerCase()!=='select country'){
          state.setAttribute('style','visibility:visible');

         }

       }

        //this function is checking whether city selected and then showing state/region

       function checkState(){
        let state = document.querySelector('#manual_region_value');
         let city = document.querySelector('.manual_city');
         let citySelect = document.querySelector("#manual_city_value");

         citySelect.textContent = "";

         let foundState = stateInfo.filter((item)=>{
           return item.state.toLowerCase()===state.value.toLowerCase();
         });

         if(foundState.length > 0){
          foundState = foundState[0];
          let selectOption = document.createElement('option');
          selectOption.textContent = "Select City";
            citySelect.appendChild(selectOption);

          foundState.cities.forEach((item)=>{
            let option = document.createElement('option');
            option.value = item;
            option.textContent = item;
            citySelect.appendChild(option);
          })
         }

         if(state.value && state.value.toLowerCase()!=='select state/region'){
          city.setAttribute('style','visibility:visible')
         }



       }

        //this function is checking whether state selected and then showing zip/pin code field
       function checkCity(){
        let city = document.querySelector('#manual_city_value');
         let zip = document.querySelector('.manual_zip');
         if(city.value && city.value.toLowerCase()!=='select city'){
          zip.setAttribute('style','visibility:visible')
         }
       }
        // start of SpeechRecog
        //console.log(DETAIL.Name.value)
