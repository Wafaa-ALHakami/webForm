const usernameEl = document.querySelector('#name');
const emailEl = document.querySelector('#email');
const passwordEl = document.querySelector('#pass');
const confirmPasswordEl = document.querySelector('#repass');

const form = document.querySelector('#signup');

//Name validation
const checkUsername = () => {

  let valid = false;
  const min = 2,
    max = 25;
  const username = usernameEl.value.trim();
  if (!isRequired(username))
  {
    usernameEl.setAttribute("aria-invalid", "true");

    showError(usernameEl, 'Username cannot be blank.');
  }
   else if (!isBetween(username.length, min, max))
   {
      usernameEl.setAttribute("aria-invalid", "true");
    showError(usernameEl, `Username must be between ${min} and ${max} characters.`)
  }
  else {
      usernameEl.setAttribute("aria-invalid", "false");
      showSuccess(usernameEl);
      valid = true;
  }
  return valid;
};

//Email validation
const checkEmail = () => {
  let valid = false;
  const email = emailEl.value.trim();
  if (!isRequired(email))
   {
      emailEl.setAttribute("aria-invalid", "true");
    showError(emailEl, 'Email cannot be blank.');
  }
  else if (!isEmailValid(email))
   {
    emailEl.setAttribute("aria-invalid", "true");
    showError(emailEl, 'Email is not valid, it must match email@example.com');
  }
  /*else if (!isEmailValid(email) && (/[^0-9]/).test(email)) {
      showError(emailEl, 'Email is not valid,  Should not start with number ');
  }*/
  else {
    showSuccess(emailEl);
    emailEl.setAttribute("aria-invalid", "false");
    valid = true;
    //emailEl.disabled = true;
  }
  return valid;
};

const checkPassword = () => {
  let valid = false;


  const password = passwordEl.value.trim();

  if (!isRequired(password))
   {
    showError(passwordEl, 'Password cannot be blank.');
  }
  else if (!isPasswordSecure(password))
  {
    showError(passwordEl, 'Password must has at least 8 characters that include at least 1 lowercase character, 1 uppercase characters, 1 number, and 1 special character in (!@#$%^&*)');
}
  else
  {
    showSuccess(passwordEl);
    valid = true;
  }
  return valid;
};

const checkConfirmPassword = () => {
  let valid = false;
  // check confirm password
  const confirmPassword = confirmPasswordEl.value.trim();
  const password = passwordEl.value.trim();

  if (!isRequired(confirmPassword)) {
    showError(confirmPasswordEl, 'Please enter the password again');
  } else if (password !== confirmPassword) {
    showError(confirmPasswordEl, 'The password does not match');
  } else {
    showSuccess(confirmPasswordEl);
    valid = true;
  }

  return valid;
};

const isEmailValid = (email) => {
  const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
};

const isPasswordSecure = (password) => {
  const re = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})");
  return re.test(password);
};

const isRequired = value => value === '' ? false : true;
const isBetween = (length, min, max) => length < min || length > max ? false : true;


const showError = (input, message) => {
  // get the form-field element
  const formField = input.parentElement;
  // add the error class
  formField.classList.remove('success');
  formField.classList.add('error');

  // show the error message
  const error = formField.querySelector('p');
  error.textContent = message;
};

const showSuccess = (input) => {
  // get the form-field element
  const formField = input.parentElement;

  // remove the error class
  formField.classList.remove('error');
  formField.classList.add('success');

  // hide the error message
  const error = formField.querySelector('p');
  error.textContent = '';
}


form.addEventListener('submit', function(e) {
  // prevent the form from submitting
  e.preventDefault();

  // validate fields
  let isUsernameValid = checkUsername(),
    isEmailValid = checkEmail(),
    isPasswordValid = checkPassword(),
    isConfirmPasswordValid = checkConfirmPassword();

  let isFormValid = isUsernameValid &&
    isEmailValid &&
    isPasswordValid &&
    isConfirmPasswordValid;

    // submit to the server if the form is valid and read the message if success or no
    if (isFormValid) {
      $(document.getElementById("err_final")).text("successful entery").focus();
    }
    else {
      $(document.getElementById("err_final")).text("Sorry cannot login: Please fix the errors and retry").focus();
      //document.getElementByTagName("input").disabled = true;
      //document.getElementsByTagName("input").style.backgroundColor = "red";
      //setAttribute(tabindex)
      return false;
    }
});


const debounce = (fn, delay = 1500) => {
  let timeoutId;
  return (...args) => {
    // cancel the previous timer
    if (timeoutId) {
      clearTimeout(timeoutId);
    }
    // setup a new timer
    timeoutId = setTimeout(() => {
      fn.apply(null, args)
    }, delay);
  };
};

form.addEventListener('input', debounce(function(e) {
  switch (e.target.id) {
    case 'name':
      checkUsername();
      break;
    case 'email':
      checkEmail();
      break;
    case 'pass':
      checkPassword();
      break;
    case 'repass':
      checkConfirmPassword();
      break;
  }
}));
