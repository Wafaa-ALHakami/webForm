function changeColors (newCSS)
{
  document.getElementById('currentCSS').href = newCSS;
}
