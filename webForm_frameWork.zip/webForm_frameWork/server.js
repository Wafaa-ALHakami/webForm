
const express = require("express");
const app = express();
const ejs = require('ejs');
const PORT = 5000;
const fs = require("fs");
//var http = require('http');
const pdfparse = require("pdf-parse");
const bodyParser = require('body-parser')
const { check, validationResult } = require('express-validator')
const fileUpload = require("express-fileupload");
const DETAIL = {
  Name: "",
  Phone: "",
  Email: "",
  Country: "",
  Age: "",
  Pass: "",
};

// Static Files
app.use(express.static("public"));
app.use(express.json())
app.use(express.urlencoded({ extended: true }));
//app.use(cors())
//Set Views
app.set("views", "./view");
app.set("view engine", "ejs");

const urlencodedParser = bodyParser.urlencoded({ extended: false })


app.use(fileUpload());

app.get("/", (req, res) => {
res.render(__dirname + "/view/index.ejs");
});


app.post("/upload", (req, res) => {
  DETAIL.Name = "";
  DETAIL.Phone = "";
  DETAIL.Email = "";
  DETAIL.Country = "";
  DETAIL.Age = "";
  DETAIL.Pass="";
  console.log(DETAIL);
  if (req.files) {
    console.log("file ", req.files);
    var file = req.files.inpFile;
    var filename = file.name;
    file.mv("./uploads/" + filename, function (err) {
      if (err) {
        res.send(err);
      } else {
        // res.send("File Uploaded..");
        var path = __dirname + "/uploads/" + filename;
        const pdffile = fs.readFileSync(path);
        pdfparse(pdffile).then(function (data) {
          const lines = data.text.split(/\r\n|\n/);
          console.log(data.text);
          for (i = 0; i < lines.length; i++) {
            console.log(i, ". ", lines[i]);
            if (DETAIL.Name == "") {
              if (lines[i] != "") {
                DETAIL.Name = lines[i];
              }
            }
            if (/Name:|name:|NAME:|Name/i.test(lines[i])) {
              console.log(i, ". ", lines[i]);
              DETAIL.Name = splitData(lines[i]);
              console.log(DETAIL.Name.length);
              if (DETAIL.Name.trim() == "") {
                DETAIL.Name = lines[i + 1];
              }
            }
            if (/Phone:|phone:|PHONE:|Phone/i.test(lines[i])) {
              console.log(i, ". ", lines[i]);
              DETAIL.Phone = splitData(lines[i]);
              if (DETAIL.Phone.trim() == "") {
                DETAIL.Phone = lines[i + 1];
              }
            }
            if (/Email:|email:|EMAIL:|E-Mail/i.test(lines[i])) {
              console.log(i, ". ", lines[i]);
              DETAIL.Email = splitData(lines[i]);
              if (DETAIL.Email.trim() == "") {
                DETAIL.Email = lines[i + 1];
              }
            }
            if (/country:|country|Address/i.test(lines[i])) {
              console.log(i, ". ", lines[i]);
              DETAIL.Country = splitData(lines[i]);
              if (DETAIL.Country.trim() == "") {
                DETAIL.Country = lines[i + 1];
              }
            }
            if (/Age:|age:|Old:/i.test(lines[i])) {
              console.log(i, ". ", lines[i]);
              DETAIL.Age = splitData(lines[i]);
              if (DETAIL.Age.trim() == "") {
                DETAIL.Age = lines[i + 1];
              }
            }
            if (/Password:|Pass:/i.test(lines[i])) {
              console.log(i, ". ", lines[i]);
              DETAIL.Pass = splitData(lines[i]);
              if (DETAIL.Pass.trim() == "") {
                DETAIL.Pass = lines[i + 1];
              }
            }

          }

          fs.unlink(path, function (err) {
            if (err) {
              console.log(err);
            } else {
              console.log("file Delete Successfully");
            }
          });
          console.log(DETAIL);
          res.status(200).json(DETAIL);
        });
      }
    });
  }
});
//for registering

app.locals.gender = ['Male','Female']
app.locals.months = [
  'January','February','March','April',
'May','June','July','August','September',
'October','November','December'
]

app.locals.nationality = ['Armenian','Russian','German','French','American','English']

app.post('/register', [
    check('email', 'Email is not valid')
        .isEmail()
        .exists(),

        check('password', 'The password must be 6+ chars long and contain a number')
        .isLength({ min: 6 })
        .exists()
        .matches(/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/, "i")
        .withMessage("Password should contain letters,Numbers and atleast 1 special symbol!"),

        check('phoneNumber','Phone Number should contain 10 Digits (only numbers)')
        .exists()
        .isLength({min:10})
        .matches(/^[0-9]+$/) .withMessage('Phone Number should have numbers only!')
        .isInt().withMessage('Only Integer Digits are allowed!'),

        check('confirmPassword','The Password is required').exists(),

        check('fName','Name is not valid')
        .exists()
        .withMessage('Name is required!')
        .isString()
        .withMessage('Only string is allowed!')
        .matches(/^[a-zA-Z\s]*$/)
        .withMessage('Enter only a text data without using any numbers and special symbol!')

], (req, res)=> {
  const errors = validationResult(req)
  console.log("Validation Result : ",errors);
  if(!errors.isEmpty()) {
      // return res.status(422).jsonp(errors.array())
      const alert = errors.array()
      const getIsError = (inputParam)=>{
       let error =  alert.find((item)=>{
          return item.param===inputParam
        })
        console.log("error : ",error);
        return error;
      }

      console.log("Errors array : ",alert);
      console.log("Form Data : ",req.body);
      res.render("form",{formData:req.body,isErrors:true,getIsError:getIsError});

  }else{
    console.log("Form Data : ",req.body);
    res.render("success",{msg:'Form Submitted successfully!'});
  }


})



function splitData(data) {
  if (data.includes(":")) {
    var splitInfo = data.split(":");
    var Info = {
      type: splitInfo[0],
      value: splitInfo[1],
    };
    return Info.value;
  }
}


app.listen(PORT, () => {
  console.log(`localhost:${PORT}`);
});
